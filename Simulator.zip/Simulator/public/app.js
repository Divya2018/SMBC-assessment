async function api(path, method='GET', body=null) {
  const opts = { method, headers: {} };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch('/api' + path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw data;
  return data;
}

function el(id) { return document.getElementById(id); }

async function refreshCars() {
  try {
    const data = await api('/cars');
    const cars = data.cars || [];
    const container = el('cars');
    if (cars.length === 0) {
      container.innerText = 'No cars yet.';
      return;
    }
    container.innerHTML = '';
    for (const c of cars) {
      const div = document.createElement('div');
      div.className = 'car-item';
      div.innerText = `${c.name}, (${c.x},${c.y}) ${c.direction}, ${c.commands}`;
      container.appendChild(div);
    }
  } catch (e) {
    el('cars').innerText = 'Error loading cars.';
    el('cars').style.color = 'red';
  }
}

async function refreshFieldInfo() {
  try {
    const data = await api('/field');
    if (data.field) {
      el('field-info').innerText = `Field: ${data.field.width} x ${data.field.height}`;
    } else {
      el('field-info').innerText = 'No field created yet.';
      el('field-info').style.color = 'red';
    }
  } catch (e) {
    el('field-info').innerText = 'Error loading field.';
    el('field-info').style.color = 'red';
  }
}

document.getElementById('create-field').addEventListener('click', async () => {
  const width = parseInt(el('width').value, 10);
  const height = parseInt(el('height').value, 10);
  try {
    const res = await api('/field', 'POST', { width, height });
    el('field-info').innerText = res.message;
    el('add-car-msg').innerText = '';
    await refreshCars();
  } catch (err) {
    el('field-info').innerText = err.error || 'Error creating field';
    el('field-info').style.color = 'red';
  }
});

document.getElementById('add-car').addEventListener('click', async () => {
  const name = el('car-name').value.trim();
  const x = parseInt(el('car-x').value, 10);
  const y = parseInt(el('car-y').value, 10);
  const direction = el('car-dir').value;
  const commands = el('car-cmds').value.trim();
  try {
    const res = await api('/cars', 'POST', { name, x, y, direction, commands });
    el('add-car-msg').innerText = `Added Car ${res.car.name}`;
    el('car-name').value = '';
    el('car-cmds').value = '';
    await refreshCars();
  } catch (err) {
    el('add-car-msg').innerText = err.error || 'Error adding car';
    el('add-car-msg').style.color = 'red';
  }
});

document.getElementById('run-sim').addEventListener('click', async () => {
  try {
    const res = await api('/run', 'POST');
    el('run-msg').innerText = 'Simulation complete. Final positions shown below.';
    const container = el('cars');
    container.innerHTML = '';
    // res.result is an array of objects with either collision or final pos
    for (const item of res.result) {
      const div = document.createElement('div');
      div.className = 'car-item';
      if (item.collision) {
        const c = item.collision;
        div.innerText = `${item.name}, collides with ${c.other} at (${c.x},${c.y}) at step ${c.step}`;
      } else {
        div.innerText = `${item.name}, (${item.x},${item.y}) ${item.direction}`;
      }
      container.appendChild(div);
    }
  } catch (err) {
    el('run-msg').innerText = err.error || 'Error running simulation';
  }
});


document.getElementById('reset').addEventListener('click', async () => {
  try {
    await api('/reset', 'POST');
    el('field-info').innerText = 'Reset complete. Create a new field to start.';
    el('add-car-msg').innerText = '';
    el('run-msg').innerText = '';
    await refreshCars();
  } catch (err) {
    el('run-msg').innerText = 'Error resetting';
    el('run-msg').style.color = 'red';
  }
});

// initial load
refreshFieldInfo();
refreshCars();
