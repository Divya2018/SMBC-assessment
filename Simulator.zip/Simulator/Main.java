import java.util.*;

/**
 * Main.java
 *
 * Single-file CLI Driving Simulation with collision detection.
 *
 * Compile: javac Main.java
 * Run: java Main
 */
public class Main {
    public static void main(String[] args) {
        Cli cli = new Cli();
        cli.printWelcome();

        while (true) {
            Field field = null;
            // Read field size
            while (field == null) {
                cli.promptFieldSize();
                try {
                    int[] wh = cli.readFieldSize();
                    if (wh[0] < 0 || wh[1] < 0) {
                        System.out.println("Width and height must be non-negative integers. Try again.");
                        continue;
                    }
                    field = new Field(wh[0], wh[1]);
                    System.out.println("You have created a field of " + wh[0] + " x " + wh[1] + ".");
                } catch (Exception e) {
                    System.out.println("Invalid input. Please enter two integers separated by space, e.g., '10 10'.");
                }
            }

            List<Car> cars = new ArrayList<>();
            Simulator simulator = new Simulator();

            mainMenuLoop:
            while (true) {
                cli.printMainMenu();
                int choice;
                try {
                    choice = cli.readMenuChoice();
                } catch (Exception e) {
                    System.out.println("Invalid choice. Please enter 1 or 2.");
                    continue;
                }

                if (choice == 1) {
                    // Add a car
                    String name = null;
                    while (name == null) {
                        cli.promptCarName();
                        String input = cli.readLine();
                        if (input.isEmpty()) {
                            System.out.println("Name cannot be empty. Try again.");
                            continue;
                        }
                        boolean duplicate = false;
                        for (Car c : cars) {
                            if (c.getName().equalsIgnoreCase(input)) {
                                duplicate = true;
                                break;
                            }
                        }
                        if (duplicate) {
                            System.out.println("A car with that name already exists. Choose a different name.");
                            continue;
                        }
                        name = input;
                    }

                    // Read initial position and direction
                    CarInitial initial = null;
                    while (initial == null) {
                        cli.promptCarInitialPosition(name);
                        try {
                            initial = cli.readCarInitialPosition();
                            if (!field.isInside(initial.x, initial.y)) {
                                System.out.println("Initial position is outside the field. Valid x: 0.." + field.getWidth() + " y: 0.." + field.getHeight());
                                initial = null;
                            }
                        } catch (Exception e) {
                            System.out.println("Invalid input. Example valid input: '1 2 N'.");
                        }
                    }

                    // Read commands
                    String commands = null;
                    while (commands == null) {
                        cli.promptCarCommands(name);
                        String cmd = cli.readLine().toUpperCase(Locale.ROOT).trim();
                        if (cmd.isEmpty()) {
                            // allow empty command string (car stays in place)
                            commands = "";
                            break;
                        }
                        boolean ok = true;
                        for (char ch : cmd.toCharArray()) {
                            if (ch != 'L' && ch != 'R' && ch != 'F') {
                                ok = false;
                                break;
                            }
                        }
                        if (!ok) {
                            System.out.println("Commands must only contain characters L, R, F. Try again.");
                            continue;
                        }
                        commands = cmd;
                    }

                    Car car = new Car(name, initial.x, initial.y, initial.dir, commands);
                    cars.add(car);
                    System.out.println("Your current list of cars are:");
                    cli.printCarList(cars);

                } else if (choice == 2) {
                    // Run simulation
                    if (cars.isEmpty()) {
                        System.out.println("No cars added. Add at least one car before running the simulation.");
                        continue;
                    }
                    System.out.println("Your current list of cars are:");
                    cli.printCarList(cars);

                    System.out.println("\nAfter simulation, the result is:");
                    List<SimulationResult> results = simulator.runWithCollisions(field, cars);
                    for (SimulationResult r : results) {
                        if (r.isCollision()) {
                            System.out.println("- " + r.name + ", collides with " + r.other + " at (" + r.x + "," + r.y + ") at step " + r.step);
                        } else {
                            System.out.println("- " + r.name + ", (" + r.x + "," + r.y + ") " + r.direction);
                        }
                    }

                    // End menu
                    while (true) {
                        cli.printEndMenu();
                        int endChoice;
                        try {
                            endChoice = cli.readMenuChoice();
                        } catch (Exception e) {
                            System.out.println("Invalid choice. Please enter 1 or 2.");
                            continue;
                        }
                        if (endChoice == 1) {
                            // Start over: break to outermost loop to create new field
                            break mainMenuLoop;
                        } else if (endChoice == 2) {
                            System.out.println("\nThank you for running the simulation. Goodbye!");
                            System.exit(0);
                        } else {
                            System.out.println("Please choose 1 or 2.");
                        }
                    }
                } else {
                    System.out.println("Please choose 1 or 2.");
                }
            } // end mainMenuLoop
        } // outermost while to allow start over
    }
}

/* Simulation result holder */
class SimulationResult {
    public final String name;
    public final boolean collision;
    public final String other; // other car name if collision
    public final int x;
    public final int y;
    public final Direction direction;
    public final int step;

    private SimulationResult(String name, boolean collision, String other, int x, int y, Direction direction, int step) {
        this.name = name;
        this.collision = collision;
        this.other = other;
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.step = step;
    }

    public static SimulationResult collision(String name, String other, int x, int y, int step) {
        return new SimulationResult(name, true, other, x, y, null, step);
    }

    public static SimulationResult finalState(String name, int x, int y, Direction dir) {
        return new SimulationResult(name, false, null, x, y, dir, -1);
    }

    public boolean isCollision() { return collision; }
}

/* Simulator with collision detection */
class Simulator {

    /**
     * Run simulation step-by-step with simultaneous execution and collision detection.
     * Returns a list of SimulationResult in the same order as input cars.
     */
    public List<SimulationResult> runWithCollisions(Field field, List<Car> cars) {
// Inner classes for simulation state
class CollisionInfo {
    String other;
    int x, y;
    int step;
    CollisionInfo(String other, int x, int y, int step) {
        this.other = other; this.x = x; this.y = y; this.step = step;
    }
}
        // Inner classes for simulation state
        class State {
    String name;
    int x, y;
    Direction dir;
    String commands;
    int index; // next command index
    CollisionInfo collided; // null if not collided

    State(Car c) {
        this.name = c.getName();
        this.x = c.getX();
        this.y = c.getY();
        this.dir = c.getDirection();
        this.commands = c.getCommands();
        this.index = 0;
        this.collided = null;
    }
}

        List<State> states = new ArrayList<>();
        for (Car c : cars) states.add(new State(c));

        int maxSteps = 0;
        for (State s : states) maxSteps = Math.max(maxSteps, s.commands.length());

        // Helper
        final int W = field.getWidth();
        final int H = field.getHeight();
        java.util.function.BiPredicate<Integer,Integer> inside = (xx, yy) -> xx >= 0 && xx <= W && yy >= 0 && yy <= H;

        // Step-by-step simulation
        for (int step = 1; step <= maxSteps; step++) {
            // 1) compute tentative moves
            class Tent {
                String name;
                int fromX, fromY;
                int toX, toY;
                Direction fromDir, toDir;
                char cmd; // may be 0 if no command
                Tent(State s) {
                    this.name = s.name;
                    this.fromX = s.x; this.fromY = s.y;
                    this.fromDir = s.dir;
                    this.toX = s.x; this.toY = s.y;
                    this.toDir = s.dir;
                    this.cmd = 0;
                    if (s.collided != null) {
                        // already collided earlier: stays in place
                        return;
                    }
                    if (s.index < s.commands.length()) {
                        this.cmd = s.commands.charAt(s.index);
                        if (this.cmd == 'L') {
                            this.toDir = this.fromDir.turnLeft();
                        } else if (this.cmd == 'R') {
                            this.toDir = this.fromDir.turnRight();
                        } else if (this.cmd == 'F') {
                            int nx = this.fromX, ny = this.fromY;
                            switch (this.fromDir) {
                                case N: ny = this.fromY + 1; break;
                                case S: ny = this.fromY - 1; break;
                                case E: nx = this.fromX + 1; break;
                                case W: nx = this.fromX - 1; break;
                            }
                            if (inside.test(nx, ny)) {
                                this.toX = nx; this.toY = ny;
                            } else {
                                // move ignored, stays in place
                                this.toX = this.fromX; this.toY = this.fromY;
                            }
                        }
                    }
                }
            }

            List<Tent> tents = new ArrayList<>();
            for (State s : states) tents.add(new Tent(s));

            // 2) detect same-cell collisions (multiple tents with same toX,toY)
            Map<String, List<Tent>> posMap = new HashMap<>();
            for (Tent t : tents) {
                String key = t.toX + "," + t.toY;
                posMap.computeIfAbsent(key, k -> new ArrayList<>()).add(t);
            }
            // mark same-cell collisions
            for (Map.Entry<String, List<Tent>> e : posMap.entrySet()) {
                List<Tent> list = e.getValue();
                if (list.size() > 1) {
                    String[] parts = e.getKey().split(",");
                    int cx = Integer.parseInt(parts[0]);
                    int cy = Integer.parseInt(parts[1]);
                    for (Tent t : list) {
                        State s = null;
                        for (State ss : states) if (ss.name.equals(t.name)) { s = ss; break; }
                        if (s != null && s.collided == null) {
                            // choose other as first different name
                            String other = null;
                            for (Tent tt : list) if (!tt.name.equals(t.name)) { other = tt.name; break; }
                            if (other == null) other = list.get(0).name;
                            s.collided = new CollisionInfo(other, cx, cy, step);
                        }
                    }
                }
            }

            // 3) detect swap collisions (A.to == B.from && B.to == A.from)
            for (int i = 0; i < tents.size(); i++) {
                for (int j = i + 1; j < tents.size(); j++) {
                    Tent a = tents.get(i);
                    Tent b = tents.get(j);
                    State sa = null, sb = null;
                    for (State ss : states) {
                        if (ss.name.equals(a.name)) sa = ss;
                        if (ss.name.equals(b.name)) sb = ss;
                    }
                    if (sa == null || sb == null) continue;
                    if (sa.collided != null || sb.collided != null) continue; // already collided
                    boolean swap = (a.toX == b.fromX && a.toY == b.fromY && b.toX == a.fromX && b.toY == a.fromY)
                                   && !(a.toX == a.fromX && a.toY == a.fromY && b.toX == b.fromX && b.toY == b.fromY);
                    if (swap) {
                        sa.collided = new CollisionInfo(sb.name, a.toX, a.toY, step);
                        sb.collided = new CollisionInfo(sa.name, b.toX, b.toY, step);
                    }
                }
            }

            // 4) apply tentative moves and update directions and indices
            for (Tent t : tents) {
                State s = null;
                for (State ss : states) if (ss.name.equals(t.name)) { s = ss; break; }
                if (s == null) continue;
                // update position and direction to tentative values
                s.x = t.toX;
                s.y = t.toY;
                s.dir = t.toDir;
                // advance index if there was a command
                if (t.cmd != 0) {
                    s.index++;
                }
            }

            // 5) stop early if no active cars remain (no commands left or all collided)
            boolean anyActive = false;
            for (State s : states) {
                if (s.collided == null && s.index < s.commands.length()) {
                    anyActive = true;
                    break;
                }
            }
            if (!anyActive) break;
        } // end steps

        // Build results in same order as input cars
        List<SimulationResult> results = new ArrayList<>();
        for (State s : states) {
            if (s.collided != null) {
                results.add(SimulationResult.collision(s.name, s.collided.other, s.collided.x, s.collided.y, s.collided.step));
            } else {
                results.add(SimulationResult.finalState(s.name, s.x, s.y, s.dir));
            }
        }

        // Update original car objects to final positions/directions (so subsequent runs reflect final state)
        for (SimulationResult r : results) {
            for (Car c : cars) {
                if (c.getName().equals(r.name)) {
                    if (r.isCollision()) {
                        c.setPosition(r.x, r.y);
                    } else {
                        c.setPosition(r.x, r.y);
                        c.setDirection(r.direction);
                    }
                }
            }
        }

        return results;
    }
}

/* CLI helper */
class Cli {
    private final Scanner scanner = new Scanner(System.in);

    public void printWelcome() {
        System.out.println("Welcome to Car Crash Java!\n");
    }

    public void promptFieldSize() {
        System.out.println("Please enter the width and heigh of the simulation field in x y format:");
    }

    public int[] readFieldSize() {
        String line = scanner.nextLine().trim();
        String[] parts = line.split("\\s+");
        if (parts.length < 2) throw new IllegalArgumentException("Need two integers");
        int width = Integer.parseInt(parts[0]);
        int height = Integer.parseInt(parts[1]);
        return new int[] { width, height };
    }

    public void printMainMenu() {
        System.out.println("\nPlease choose from the following options:");
        System.out.println("[1] Add a car to field");
        System.out.println("[2] Run simulation");
    }

    public int readMenuChoice() {
        String line = scanner.nextLine().trim();
        return Integer.parseInt(line);
    }

    public void promptCarName() {
        System.out.println("\nPlease enter the name of the car:");
    }

    public void promptCarInitialPosition(String name) {
        System.out.println("\nPlease enter initial position of car " + name + " in x y Direction format:");
    }

    public CarInitial readCarInitialPosition() {
        String line = scanner.nextLine().trim();
        String[] parts = line.split("\\s+");
        if (parts.length < 3) throw new IllegalArgumentException("Need x y Direction");
        int x = Integer.parseInt(parts[0]);
        int y = Integer.parseInt(parts[1]);
        Direction dir = Direction.fromString(parts[2]);
        return new CarInitial(x, y, dir);
    }

    public void promptCarCommands(String name) {
        System.out.println("\nPlease enter the commands for car " + name + ":");
    }

    public String readLine() {
        return scanner.nextLine().trim();
    }

    public void printCarList(List<Car> cars) {
        for (Car c : cars) {
            System.out.println("- " + c.getName() + ", (" + c.getX() + "," + c.getY() + ") " + c.getDirection() + ", " + c.getCommands());
        }
    }

    public void printEndMenu() {
        System.out.println("\nPlease choose from the following options:");
        System.out.println("[1] Start over");
        System.out.println("[2] Exit");
    }
}

/* Helper to hold initial parsed car data */
class CarInitial {
    public final int x;
    public final int y;
    public final Direction dir;
    public CarInitial(int x, int y, Direction dir) {
        this.x = x; this.y = y; this.dir = dir;
    }
}

/* Field class */
class Field {
    private final int width;
    private final int height;

    public Field(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public boolean isInside(int x, int y) {
        return x >= 0 && x <= width && y >= 0 && y <= height;
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }
}

/* Direction enum */
enum Direction {
    N, E, S, W;

    public Direction turnLeft() {
        switch (this) {
            case N: return W;
            case W: return S;
            case S: return E;
            case E: return N;
            default: return N;
        }
    }

    public Direction turnRight() {
        switch (this) {
            case N: return E;
            case E: return S;
            case S: return W;
            case W: return N;
            default: return N;
        }
    }

    public static Direction fromString(String s) {
        if (s == null || s.isEmpty()) throw new IllegalArgumentException("Empty direction");
        s = s.trim().toUpperCase(Locale.ROOT);
        switch (s) {
            case "N": return N;
            case "E": return E;
            case "S": return S;
            case "W": return W;
            default: throw new IllegalArgumentException("Unknown direction: " + s);
        }
    }
}

/* Car class */
class Car {
    private final String name;
    private int x;
    private int y;
    private Direction dir;
    private final String commands;

    public Car(String name, int x, int y, Direction dir, String commands) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.dir = dir;
        this.commands = commands == null ? "" : commands;
    }

    public String getName() { return name; }
    public int getX() { return x; }
    public int getY() { return y; }
    public Direction getDirection() { return dir; }
    public String getCommands() { return commands; }

    public void setPosition(int nx, int ny) { this.x = nx; this.y = ny; }
    public void setDirection(Direction d) { this.dir = d; }

    // Note: executeCommands is not used for collision-aware simulation
    public void executeCommands(Field field) {
        for (char c : commands.toCharArray()) {
            if (c == 'L') {
                dir = dir.turnLeft();
            } else if (c == 'R') {
                dir = dir.turnRight();
            } else if (c == 'F') {
                attemptMove(field);
            }
        }
    }

    private void attemptMove(Field field) {
        int nx = x, ny = y;
        switch (dir) {
            case N: ny = y + 1; break;
            case S: ny = y - 1; break;
            case E: nx = x + 1; break;
            case W: nx = x - 1; break;
        }
        if (field.isInside(nx, ny)) {
            x = nx; y = ny;
        } // else ignore move
    }
}
