#!/usr/bin/env bash
set -e

# Install dependencies and start server
if [ ! -f package.json ]; then
  echo "package.json not found. Make sure you are in the project root."
  exit 1
fi

echo "Installing dependencies..."
npm install

echo "Starting server on http://localhost:3000"
node app.js
