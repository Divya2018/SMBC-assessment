#!/usr/bin/env bash
set -e

# Clean previous classes to ensure fresh start
rm -f *.class

echo "Compiling Main.java..."
javac Main.java

echo "Starting Car Crash Java..."
java Main
