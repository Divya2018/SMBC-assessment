const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory state (reset on server restart)
let field = null; // { width, height }
let cars = [];    // array of Car objects

// Helper: Direction enum and helpers
const Direction = {
  N: 'N', E: 'E', S: 'S', W: 'W',
  turnLeft(dir) {
    switch (dir) {
      case 'N': return 'W';
      case 'W': return 'S';
      case 'S': return 'E';
      case 'E': return 'N';
      default: return dir;
    }
  },
  turnRight(dir) {
    switch (dir) {
      case 'N': return 'E';
      case 'E': return 'S';
      case 'S': return 'W';
      case 'W': return 'N';
      default: return dir;
    }
  }
};

// Field endpoints
app.post('/api/field', (req, res) => {
  const { width, height } = req.body;
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 0 || height < 0) {
    return res.status(400).json({ error: 'width and height must be non-negative integers' });
  }
  field = { width, height };
  cars = []; // clear cars when new field created
  res.json({ message: `Field created ${width} x ${height}` });
});

app.get('/api/field', (req, res) => {
  res.json({ field });
});

// Car endpoints
app.post('/api/cars', (req, res) => {
  if (!field) return res.status(400).json({ error: 'Create a field first' });
  const { name, x, y, direction, commands } = req.body;
  if (!name || typeof name !== 'string') return res.status(400).json({ error: 'name required' });
  if (!Number.isInteger(x) || !Number.isInteger(y)) return res.status(400).json({ error: 'x and y must be integers' });
  if (!['N','E','S','W'].includes(direction)) return res.status(400).json({ error: 'direction must be N,E,S or W' });
  if (x < 0 || x > field.width || y < 0 || y > field.height) return res.status(400).json({ error: 'initial position outside field' });
  if (cars.some(c => c.name.toLowerCase() === name.toLowerCase())) return res.status(400).json({ error: 'duplicate car name' });
  const cmd = (commands || '').toUpperCase();
  for (const ch of cmd) {
    if (!['L','R','F'].includes(ch)) return res.status(400).json({ error: 'commands must contain only L,R,F' });
  }
  const car = { name, x, y, direction, commands: cmd };
  cars.push(car);
  res.json({ message: 'car added', car });
});

app.get('/api/cars', (req, res) => {
  res.json({ cars });
});

// Run simulation (synchronous step-by-step with collision detection)
app.post('/api/run', (req, res) => {
  if (!field) return res.status(400).json({ error: 'Create a field first' });
  if (cars.length === 0) return res.status(400).json({ error: 'No cars to simulate' });

  // Prepare per-car state
  const state = cars.map(c => ({
    name: c.name,
    x: c.x,
    y: c.y,
    direction: c.direction,
    commands: c.commands || '',
    stepIndex: 0,
    collided: null // { other: 'B', x: 5, y: 4, step: 7 }
  }));

  // Helper to check inside field
  const inside = (x, y) => x >= 0 && x <= field.width && y >= 0 && y <= field.height;

  // Maximum number of steps is the longest command string
  const maxSteps = Math.max(...state.map(s => s.commands.length), 0);

  // Run steps synchronously
  for (let step = 1; step <= maxSteps; step++) {
    // 1) Compute tentative new positions and directions for this step
    const tentative = state.map(s => {
      if (s.collided) {
        // If already collided earlier, it no longer moves
        return { name: s.name, fromX: s.x, fromY: s.y, toX: s.x, toY: s.y, fromDir: s.direction, toDir: s.direction };
      }
      const cmd = s.commands.charAt(s.stepIndex) || ''; // may be ''
      let nx = s.x, ny = s.y, nd = s.direction;
      if (cmd === 'L') nd = Direction.turnLeft(s.direction);
      else if (cmd === 'R') nd = Direction.turnRight(s.direction);
      else if (cmd === 'F') {
        // move forward based on current direction
        switch (s.direction) {
          case 'N': ny = s.y + 1; break;
          case 'S': ny = s.y - 1; break;
          case 'E': nx = s.x + 1; break;
          case 'W': nx = s.x - 1; break;
        }
        // boundary check: if outside, ignore move (stay in place)
        if (!inside(nx, ny)) { nx = s.x; ny = s.y; }
      }
      return { name: s.name, fromX: s.x, fromY: s.y, toX: nx, toY: ny, fromDir: s.direction, toDir: nd, cmd };
    });

    // 2) Detect collisions:
    // - same-cell collisions: multiple cars with same toX,toY
    // - swap collisions: A.to == B.from && B.to == A.from
    const posMap = new Map(); // key "x,y" -> [names]
    for (const t of tentative) {
      const key = `${t.toX},${t.toY}`;
      if (!posMap.has(key)) posMap.set(key, []);
      posMap.get(key).push(t.name);
    }

    // Record same-cell collisions
    for (const [key, names] of posMap.entries()) {
      if (names.length > 1) {
        // collision among all names at this cell
        const [sx, sy] = key.split(',').map(Number);
        for (const n of names) {
          const s = state.find(x => x.name === n);
          if (!s.collided) {
            // choose another car involved as "other" (first different name)
            const other = names.find(x => x !== n) || names[0];
            s.collided = { other, x: sx, y: sy, step };
          }
        }
      }
    }

    // Record swap collisions (head-on crossing)
    for (let i = 0; i < tentative.length; i++) {
      for (let j = i + 1; j < tentative.length; j++) {
        const a = tentative[i], b = tentative[j];
        // if already recorded via same-cell, skip
        const sa = state.find(x => x.name === a.name);
        const sb = state.find(x => x.name === b.name);
        if (sa.collided || sb.collided) continue;

        const swap = (a.toX === b.fromX && a.toY === b.fromY && b.toX === a.fromX && b.toY === a.fromY);
        if (swap) {
          // record collision for both at the crossing step
          // choose collision coordinate as the pair of positions they swapped into;
          // for reporting, use a.toX,a.toY (which equals b.fromX,b.fromY) for A,
          // and b.toX,b.toY for B (which equals a.fromX,a.fromY).
          sa.collided = { other: sb.name, x: a.toX, y: a.toY, step };
          sb.collided = { other: sa.name, x: b.toX, y: b.toY, step };
        }
      }
    }

    // 3) Apply tentative moves and direction updates for cars that haven't collided this step
    for (const t of tentative) {
      const s = state.find(x => x.name === t.name);
      // If s.collided was set this step (by same-cell or swap), we still update position to the 'to' position
      // so that collision coordinate matches the reported position. But we mark collided and further steps won't move.
      s.x = t.toX;
      s.y = t.toY;
      s.direction = t.toDir;
      // advance step index if there was a command (even if it was L/R/F)
      if (s.stepIndex < s.commands.length) s.stepIndex++;
    }

    // If all cars have collided or no more commands remain, we can stop early
    const anyActive = state.some(s => !s.collided && s.stepIndex < s.commands.length);
    if (!anyActive) {
      // but still continue to next step only if there are pending commands for some non-collided cars
      // since we already checked, break
      // However we must still allow remaining steps if some cars still have commands (anyActive true)
      break;
    }
  } // end steps loop

  // Build response: for each car, if collided -> collision message; else final pos/direction
  const result = state.map(s => {
    if (s.collided) {
      return {
        name: s.name,
        collision: {
          other: s.collided.other,
          x: s.collided.x,
          y: s.collided.y,
          step: s.collided.step
        }
      };
    } else {
      return {
        name: s.name,
        x: s.x,
        y: s.y,
        direction: s.direction
      };
    }
  });

  // Update global cars to final positions/directions (so subsequent calls reflect final state)
  for (const s of state) {
    const global = cars.find(c => c.name === s.name);
    if (global) {
      global.x = s.x;
      global.y = s.y;
      global.direction = s.direction;
    }
  }

  res.json({ message: 'simulation complete', result });
});


// Reset (start over)
app.post('/api/reset', (req, res) => {
  field = null;
  cars = [];
  res.json({ message: 'state reset' });
});

// Serve UI index.html at root (static folder already set)
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Car Crash Node UI running at http://localhost:${PORT}`);
});
